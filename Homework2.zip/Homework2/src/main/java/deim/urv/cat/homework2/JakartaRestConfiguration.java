package deim.urv.cat.homework2;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("Web")
public class JakartaRestConfiguration extends Application {
 
}

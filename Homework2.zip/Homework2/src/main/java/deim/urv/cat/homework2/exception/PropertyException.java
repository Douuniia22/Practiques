package deim.urv.cat.homework2.exception;

public class PropertyException extends RuntimeException {

    public PropertyException( String message){
        super(message);
    }
}
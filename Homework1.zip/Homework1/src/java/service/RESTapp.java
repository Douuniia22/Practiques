package service;

import jakarta.ws.rs.core.Application;

/**
 * 
 * @author Dounia
 * @author Pol
 */

@jakarta.ws.rs.ApplicationPath("webresources")
public class RESTapp extends Application {
    
    private static final String BASE_URL = "http://localhost:8080/Homework1/webresources/rest/api/v1/";
    
    
    
}
